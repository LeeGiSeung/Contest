# 인증키 9ba4eaf1485d4320b2295949e0dfbdd4
# 1. 법률안 심사 및 처리(의안검색) https://open.assembly.go.kr/portal/data/service/selectAPIServicePage.do/O4K6HM0012064I15889 
import requests
import xml.etree.ElementTree as ET
from openai import OpenAI
from bs4 import BeautifulSoup
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import csv

from flask import Flask, render_template, request, g, send_from_directory
app = Flask(__name__)


def before_request():
    #1
    g.input_name = None
    g.Age = None
    g.ing_params = None
    g.end_url = None
    g.end_params = None
    g.text = None

    #2
    g.row = None
    g.sin = None
    g.input_name = None
    g.Age = None
    g.input_content = None

app.before_request(before_request)

api = "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"
client = OpenAI(api_key=api)

# 역대 의안 통계
# https://open.assembly.go.kr/portal/data/service/selectAPIServicePage.do/OKAPKX000929X915616
api_key = "9ba4eaf1485d4320b2295949e0dfbdd4"  # 발급받은 인증키
nodata = "해당하는 데이터가 없습니다."

    # 진행중 입법 예고
ing_url = "https://open.assembly.go.kr/portal/openapi/nknalejkafmvgzmpt"

@app.route('/')
def start():
    return render_template('index.html')  

@app.route('/main')
def main():
    return render_template('main.html')

@app.route('/images/<image_name>')
def get_image(image_name):
    return send_from_directory('static/images', image_name)

@app.route('/view2',methods=['post'])
def view2():
    global file_path
    file_path = "_data.csv"

    def get_column_data(file_path, column_number):
        with open(file_path, 'r', encoding="utf-8") as csv_file:
            csv_reader = csv.reader(csv_file)
            next(csv_reader)
            column_data = [row[column_number - 1] for row in csv_reader]  # 0-based indexing
        return column_data

    def similarity(data, input_content):
        ngram_vectorizer = CountVectorizer(analyzer='char', ngram_range=(4, 4))
        new_sentence = input_content

        sim_result = []

        for i in data:
            X = ngram_vectorizer.fit_transform([new_sentence, i])
            similarity = cosine_similarity(X[0], X[1])
            sim_result.append({"new": new_sentence, "ori": i, "sim": similarity[0][0]})

        sim_result_sorted = sorted(sim_result, key=lambda x: x['sim'], reverse=True)
        most_similar_pair = sim_result_sorted[0]

        row_number = 0
        with open(str(g.Age) + g.input_name + file_path, 'r', encoding="utf-8") as csv_file:
            csv_reader = csv.reader(csv_file)
            next(csv_reader)
            for g.row in csv_reader:
                row_number += 1
                if g.row[4] == most_similar_pair["ori"]:
                    print("의안 번호 : ", g.row[0])
                    print("의안 이름 : ", g.row[1])
                    print("의안 주소 : ", g.row[2])
                    print("의안 설명 : ", g.row[3])
                    print("코사인 유사도:", most_similar_pair["sim"])
                    g.sin = most_similar_pair["sim"]

    g.input_name = request.form.get('input_name')  # request에서 값을 가져오도록 수정
    g.Age = request.form['Num']  #  if age_str is not None and age_str.isdigit() else 0request에서 값을 가져오도록 수정
    g.input_content = request.form.get('input_content')  # request에서 값을 가져오도록 수정

    data = get_column_data(str(g.Age) + g.input_name + file_path, 5)
    similarity(data, g.input_content)

    return render_template('request2.html',num = g.row[0], name = g.row[1], url = g.row[2],text = g.row[3], sin = g.sin)
   
@app.route('/view1',methods=['post'])
def view1():
    
    global file_path
    file_path = "_data.csv"

    g.input_name = request.form['Name']
    g.Age = request.form['Num']

    g.ing_params = {
        "KEY": api_key,
        "Type": "json",  # 결과를 JSON 형식으로 받고자 할 경우
        "pIndex": 1,     # 페이지 위치
        "pSize": 1,     # 페이지당 요청 건수
        "BILL_NAME":g.input_name
    }

    # 종료된 입법 예고
    g.end_url = "https://open.assembly.go.kr/portal/openapi/nohgwtzsamojdozky"
    g.end_params = {
        "KEY": api_key,
        "Type": "json",  # 결과를 JSON 형식으로 받고자 할 경우
        "AGE" : g.Age,
        "pIndex": 1,     # 페이지 위치
        "pSize": 1,     # 페이지당 요청 건수
        "BILL_NAME":g.input_name
    }
    try:
        response = requests.get(ing_url, params=g.ing_params)

        # 응답 확인
        if response.status_code == 200:
            data = response.json()
            check_data = str(data)
            # print(check_data)
            if nodata in check_data:
                g.BILL_NO = "관련된 내용이 입법되고 있지 않습니다."
                g.BILL_NAME = None
                g.LINK_URL = None
                print("\n관련된 내용이 입법되고 있지 않습니다.\n")
            else:
                row_list = data.get('nknalejkafmvgzmpt', [])[1].get('row', [])
                # 'BILL_NM'에 해당하는 값들 가져오기
                # 의안 이름
                g.BILL_NAME = [item.get('BILL_NAME') for item in row_list]
                # 의안 번호
                g.BILL_NO = [item.get('BILL_NO') for item in row_list]
                # 가결 여부
                g.LINK_URL = [item.get('LINK_URL') for item in row_list]

                print("의안 번호    : ",g.BILL_NO)
                print("의안 이름    : ",g.BILL_NAME)
                print("설명URL      : ",g.LINK_URL)

                url = g.LINK_URL
                text_content = []
                in_row = []
                for i in range(len(url)):
                    response = requests.get(url[i])
                    html_content = response.text
                    # BeautifulSoup을 사용하여 HTML을 파싱
                    soup = BeautifulSoup(html_content, "html.parser")
                    # "desc" 클래스를 가진 첫 번째 엘리먼트 찾기
                    desc_element = soup.find("div", class_="item")
                    # 해당 엘리먼트의 텍스트 가져오기
                    text = (desc_element.text if desc_element else "해당하는 데이터가 없습니다.")
                    text = str(text).replace('\n', '')  # '\n'을 공백으로 대체
                    text_content.append(text)

                    # BILL_NO[i] 의안 번호
                    # BILL_NAME[i] 의안 이름
                    # LINK_URL[i] 의안 링크
                    # text_content[i] 의안 원본 (어려운 의안)
                    # completion.choices[0].message.content ChatGPT 요약 (쉬운 의안)

                    row = [g.BILL_NO[i], g.BILL_NAME[i], g.LINK_URL[i], text_content[i]]
                    g.text = text_content[i]

                    completion = client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "You summarize difficult and long content in a short and easy way."},
                        {"role": "user", "content": text_content[i]+"이 내용 요약해줘"}
                    ]
                    )
                    print("의안 요약 설명 : ",completion.choices[0].message.content)
                    g.TEXTM = completion.choices[0].message.content
        else:
            print(f"Error: {response.status_code}, {response.text}")
            g.text = "Error: {response.status_code}, {response.text}"
    except requests.exceptions.RequestException as e:
        print(f"Request Error: {e}")
        g.text = "Request Error: {e}"

    # 종료된 입법 중 검색
    try:
        response = requests.get(g.end_url, params=g.end_params)
        # 응답 확인
        if response.status_code == 200:
            data = response.json()
            check_data = str(data)
            if nodata in check_data:
                g.BILL_NO = "관련된 내용이 입법되고 있지 않습니다."
                g.BILL_NAME = None
                g.LINK_URL = None
                print("\n종료된 입법 중 존재하지 않습니다.\n")
            else:
                row_list = data.get('nohgwtzsamojdozky', [])[1].get('row', [])
                # 'BILL_NM'에 해당하는 값들 가져오기
                # 의안 이름
                g.BILL_NAME = [item.get('BILL_NAME') for item in row_list]
                # 의안 번호
                g.BILL_NO = [item.get('BILL_NO') for item in row_list]
                # 가결 여부
                g.LINK_URL = [item.get('LINK_URL') for item in row_list]

                print("의안 번호    : ",g.BILL_NO)
                print("의안 이름    : ",g.BILL_NAME)
                print("설명URL      : ",g.LINK_URL)

                url = g.LINK_URL
                text_content = []
                in_row = []
                for i in range(len(url)):
                    response = requests.get(url[i])
                    html_content = response.text
                    # BeautifulSoup을 사용하여 HTML을 파싱
                    soup = BeautifulSoup(html_content, "html.parser")
                    # "desc" 클래스를 가진 첫 번째 엘리먼트 찾기
                    desc_element = soup.find("div", class_="item")
                    # 해당 엘리먼트의 텍스트 가져오기
                    text = (desc_element.text if desc_element else "해당하는 데이터가 없습니다.")
                    text = str(text).replace('\n', '')  # '\n'을 공백으로 대체
                    text_content.append(text)
                    # BILL_NO[i] 의안 번호
                    # BILL_NAME[i] 의안 이름
                    # LINK_URL[i] 의안 링크
                    # text_content[i] 의안 원본 (어려운 의안)
                    # completion.choices[0].message.content ChatGPT 요약 (쉬운 의안)
                    row = [g.BILL_NO[i], g.BILL_NAME[i], g.LINK_URL[i], text_content[i]]
                    g.text = text_content[i]

                    completion = client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "You summarize difficult and long content in a short and easy way."},
                        {"role": "user", "content": text_content[i]+"이 내용 요약해줘"}
                    ]
                    )
                    print("의안 요약 설명 : ",completion.choices[0].message.content)
                    g.TEXTM = completion.choices[0].message.content

        else:
            print(f"Error: {response.status_code}, {response.text}")
            g.text = "Error: {response.status_code}, {response.text}"
    except requests.exceptions.RequestException as e:
        print(f"Request Error: {e}")
        g.text = "Request Error: {e}"

    return render_template('request.html',BILL_NO=g.BILL_NO, BILL_NAME=g.BILL_NAME, LINK_URL=g.LINK_URL, TEXT=g.text, TEXTM=g.TEXTM)


if __name__ == "__main__":
    # 진행중인 입법 중 검색
    app.run(debug=True)
